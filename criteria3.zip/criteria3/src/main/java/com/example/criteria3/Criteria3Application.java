package com.example.criteria3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import  org.springframework.context.annotation.Bean;

import com.example.criteria3.model.FieldInfo;
import com.example.criteria3.service.InputService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.*;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.springframework.boot.CommandLineRunner;


@SpringBootApplication
public class Criteria3Application {

	public static void main(String[] args) {
		SpringApplication.run(Criteria3Application.class, args);
	}

	
	
	
}
