package com.example.criteria3.service;

import java.io.IOException;
import java.util.stream.Stream;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.example.criteria3.model.FieldInfo;
import com.example.criteria3.repository.InputRepository;


@Service
public class InputService {
	private final InputRepository inputRepository;

    public InputService(InputRepository inputRepository) {
        this.inputRepository = inputRepository;
    }

    public Iterable<FieldInfo> list() {
        return inputRepository.findAll();
    }

    public Iterable<FieldInfo> save(List<FieldInfo> fieldinfo) {
        return inputRepository.saveAll(fieldinfo);
    }
}
